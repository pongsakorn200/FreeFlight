<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<?php include ('check_session.php');
$presidentid=$_SESSION['presidentid'];
require_once('bdd.php');

$sql = "SELECT * FROM events where presidentid=".$presidentid;

$req = $bdd->prepare($sql);
$req->execute();

$events = $req->fetchAll();

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>จองเวลาผู้บริหาร</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/animate.css" />
    <!-- FullCalendar -->
	<link href='css/bootstrap.min.css' rel='stylesheet' />
	
	<!-- FullCalendar -->
	<link href='css/fullcalendar.css' rel='stylesheet' />
  <!-- <script src="main.js"></script> -->
</head>
<body style="background-color: rgb(253,253,150); width='100%'">
<a class="bg">
</a>
 <div class="container fadeInLeft animated">
    <nav class="navbar navbar-expand-lg navbar navbar-light" style="background-color: rgb(253,202,150);">
    <img src="img/logo.png" width="30" height="30" class="d-inline-block align-top" alt=""> Reservations</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="main_admin.php">หน้าแรก</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="logout.php">ออกจากระบบ</a>
        </li>
        </ul>
    </nav>
    </div>
    <div class="container fadeInDown animated" >
		<img src="img/img.png" class="headergg">
    </div><br>

    
    <div class="container">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>ตารางงานผู้บริหาร</h1>
                <p class="lead">***</p>
                <div id="calendar" class="col-centered">
                </div>
            </div>
			
        </div>
        <!-- /.row -->
		
		<!-- Modal -->
		<div class="modal fade" id="ModalAdd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			<form class="form-horizontal" method="POST" action="addEvent.php">
			
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">เพิ่มการจอง</h4>
			  </div>
			  <div class="modal-body">
				
				  <div class="form-group">
						<label for="title" class="col-sm-5 control-label">ชื่อผู้ติดต่อ</label>
						<div class="col-sm-10">
							<input type="text" name="fullname" class="form-control" id="fullname" placeholder="ชื่อ-นามสกุล">
						</div>
						<label for="title" class="col-sm-5 control-label">หน่วยงาน</label>
						<div class="col-sm-10">
							<input type="text" name="depart" class="form-control" id="depart" placeholder="เทศบาล">
						</div>
						<label for="title" class="col-sm-5 control-label">เบอร์โทรติดต่อ</label>
						<div class="col-sm-10">
							<input type="text" name="tel" class="form-control" id="tel" placeholder="080-0000000">
						</div>
						<label for="title" class="col-sm-2 control-label">ชื่องาน</label>
						<div class="col-sm-10">
							<input type="text" name="title" class="form-control" id="title" placeholder="Title">
						</div>
						<label for="title" class="col-sm-5 control-label">รายละเอียดของงาน</label>
						<div class="col-sm-10">
							<textarea name="detail" class="form-control" id="detail"></textarea>
						</div>
						<label for="title" class="col-sm-3 control-label">สถานที่</label>
						<div class="col-sm-10">
							<input type="text" name="local" class="form-control" id="local" placeholder="ขอนแก่น">
						</div>
						<label for="title" class="col-sm-4 control-label">เวลาเริ่มงาน</label>
						<div class="col-sm-10">
							<input type="datetime-local" name="start" class="form-control" id="start" >
						</div>
						<label for="title" class="col-sm-4 control-label">เวลาจบงาน</label>
						<div class="col-sm-10">
							<input type="datetime-local" name="end" class="form-control" id="end" >
						</div>
				  </div>
				
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
				<button type="submit" class="btn btn-primary">บันทึกการจอง</button>
			  </div>
			</form>
			</div>
		  </div>
		</div>
		
		
		
		<!-- Modal -->
		<div class="modal fade" id="ModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			<form class="form-horizontal" method="POST" action="editEventTitle.php">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">แก้ไขกิจกรรม</h4>
			  </div>
			  <div class="modal-body">
				
				<div class="form-group">
					<label for="title" class="col-sm-5 control-label">ชื่อผู้ติดต่อ</label>
					<div class="col-sm-10">
					  <input type="text" name="fullname" class="form-control" id="fullname" placeholder="ชื่อ-นามสกุล" readonly>
					</div>
					<label for="depart" class="col-sm-5 control-label">หน่วยงาน</label>
					<div class="col-sm-10">
					  <input type="text" name="depart" class="form-control" id="depart" placeholder="เทศบาล" readonly>
					</div>
					<label for="title" class="col-sm-5 control-label">เบอร์โทรติดต่อ</label>
					<div class="col-sm-10">
					  <input type="text" name="tel" class="form-control" id="tel" placeholder="080-0000000" readonly>
					</div>
					<label for="title" class="col-sm-2 control-label">ชื่องาน</label>
					<div class="col-sm-10">
					  <input type="text" name="title" class="form-control" id="title" placeholder="Title" readonly>
					</div>
					<label for="detail" class="col-sm-5 control-label">รายละเอียดของงาน</label>
					<div class="col-sm-10">
					  <textarea name="detail" class="form-control" id="detail" readonly></textarea >
					</div>
					<label for="title" class="col-sm-4 control-label">สถานที่</label>
					<div class="col-sm-10">
						<input type="text" name="local" class="form-control" id="local" placeholder="ขอนแก่น" readonly>
					</div>
					<label for="title" class="col-sm-4 control-label">เวลาเริ่มงาน</label>
					<div class="col-sm-10">
					  <input type="text" name="start" class="form-control" id="start" >
					</div>
					<label for="title" class="col-sm-4 control-label">เวลาจบงาน</label>
					<div class="col-sm-10">
					  <input type="text" name="end" class="form-control" id="end" >
					</div>
				    <div class="form-group"> 
						<div class="col-sm-offset-2 col-sm-10">
						  <div class="checkbox">
							<label class="text-danger"><input type="checkbox" name="approve" id='approve' value='active'>อนุมัติการจอง</label>
						  </div>
						</div>
					</div>
				  
				  <input type="hidden" name="id" class="form-control" id="id">
				
				
			  </div>
			  <div class="modal-footer">
                <button type="submit" class="btn btn-secodary" name='delete'>ลบการจอง</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
				<button type="submit" class="btn btn-primary" name='submit'>บันทึกการแก้ไข</button>
			  </div>
			</form>
			</div>
		  </div>
		</div>

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- FullCalendar -->
	<script src='js/moment.min.js'></script>
	<script src='js/fullcalendar.min.js'></script>
	
	<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},

			defaultDate: $('#calendar').fullCalendar('today'),
			editable: false,
			eventLimit: true, // allow "more" link when too many events
			selectable: true,
			selectHelper: true,
			select: function(start, end) {
				
				$('#ModalAdd #start').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd #end').val(moment(end).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd').modal('show');
			},
			eventRender: function(event, element) {
				element.bind('dblclick', function() {
					$('#ModalEdit #id').val(event.id);
					$('#ModalEdit #title').val(event.title);
					$('#ModalEdit #fullname').val(event.fullname);
					$('#ModalEdit #tel').val(event.tel);
					$('#ModalEdit #detail').val(event.detail);
					$('#ModalEdit #local').val(event.local);
					$('#ModalEdit #depart').val(event.depart);
					$('#ModalEdit #start').val(event.start);
					$('#ModalEdit #end').val(event.end);
					$('#ModalEdit').modal('show');
				});
			},
			eventDrop: function(event, delta, revertFunc) { // si changement de position

				edit(event);

			},
			eventResize: function(event,dayDelta,minuteDelta,revertFunc) { // si changement de longueur

				edit(event);

			},
			events: [
			<?php foreach($events as $event): 
			
				$start = explode(" ", $event['start']);
				$end = explode(" ", $event['end']);
				if($start[1] == '00:00:00'){
					$start = $start[0];
				}else{
					$start = $event['start'];
				}
				if($end[1] == '00:00:00'){
					$end = $end[0];
				}else{
					$end = $event['end'];
				}
			?>
				{
					id: '<?php echo $event['id']; ?>',
					fullname: '<?php echo $event['fullname']; ?>',
					depart: '<?php echo $event['depart']; ?>',
					tel: '<?php echo $event['tel']; ?>',
					detail: '<?php echo $event['detail']; ?>',	
					title: '<?php echo $event['title']; ?>',
					local: '<?php echo $event['local']; ?>',	
					color: '<?php echo $event['color']; ?>',	
					start: '<?php echo $start ?>',
					end: '<?php echo $end; ?>',
				},
			<?php endforeach; ?>
			]
		});
		
		function edit(event){
			start = event.start.format('YYYY-MM-DD HH:mm:ss');
			if(event.end){
			end = event.end.format('YYYY-MM-DD HH:mm:ss');
			}else{
				end = start;
			}
			
			id =  event.id;
			
			Event = [];
			Event[0] = id;
			Event[1] = start;
			Event[2] = end;
			
			$.ajax({
			 url: '',
			 type: "POST",
			 data: {Event:Event},
			 success: function(rep) {
					if(rep == 'OK'){
						alert('test Saved');
					}else{
	 					alert('Could not be saved. try again.'); 
				    } 
				} 
			}); 
		}
		
	});

</script>
</body>
</html>
