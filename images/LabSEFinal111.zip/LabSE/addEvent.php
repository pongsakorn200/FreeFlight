<?php
session_start();
// Connexion à la base de données
require_once('bdd.php');
//echo $_POST['title'];
if (isset($_POST['title']) && isset($_POST['start']) && isset($_POST['end'])){
	
	$title = $_POST['title'];
	$start = $_POST['start'];
	$end = $_POST['end'];
	$color = '#ffbd91';
	$fullname = $_POST['fullname'];
	$tel = $_POST['tel'];
	$depart = $_POST['depart'];
	$detail = $_POST['detail'];
	$local = $_POST['local'];


	$sql = "INSERT INTO events(fullname, depart, tel, detail, title,local, color, start, end, presidentid) 
	values ('$fullname','$depart','$tel','$detail','$title','$local','$color', '$start', '$end','".$_SESSION['presidentid']."')";
	//$req = $bdd->prepare($sql);
	//$req->execute();
	
	echo $sql;
	
	$query = $bdd->prepare( $sql );
	if ($query == false) {
	 print_r($bdd->errorInfo());
	 die ('Erreur prepare');
	}
	$sth = $query->execute();
	if ($sth == false) {
	 print_r($query->errorInfo());
	 die ('Erreur execute');
	}

}
header('Location: '.$_SERVER['HTTP_REFERER']);

	
?>
