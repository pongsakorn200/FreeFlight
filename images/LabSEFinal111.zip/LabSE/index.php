<?php
    require_once('bdd.php');
    if (isset($_POST['filterpresident'])){
        $presidentid=$_POST['filterpresident'];
        if($presidentid==" "){
            $sql = "SELECT * FROM events";
        }
        else{

        $sql = "SELECT * FROM events where presidentid=".$presidentid;
        }
        
    }
    else{
        $sql = "SELECT * FROM events";
    }

    $req = $bdd->prepare($sql);
    $req->execute();

    $events = $req->fetchAll();

    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>จองเวลาผู้บริหาร</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/animate.css" />
    <link href='css/bootstrap.min.css' rel='stylesheet' />
	
	<!-- FullCalendar -->
	<link href='css/fullcalendar.css' rel='stylesheet' />

    <script src="main.js"></script>
</head>
<body style="background-color: rgb(253,253,150); width='100%'">
<a class="bg">
</a>
 <div class="container fadeInLeft animated">
    <nav class="navbar navbar-expand-lg navbar navbar-light" style="background-color: rgb(253,202,150);">
    <img src="img/logo.png" width="30" height="30" class="d-inline-block align-top" alt=""> Reservations</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="index.php">หน้าแรก</a>
        </li>
        <li class="nav-item">
			<a class="nav-link" data-toggle="modal" data-target="#loginModal">เข้าสู่ระบบ</a>
        </li>
        </ul>
    </nav>
    </div>
    <div class="container fadeInDown animated" >
    <img src="img/img.png" class="headergg">
    </div>


    <form method="POST" action="index.php"><br>
    <center><span style="font-size:25px; "><strong>กรุณาเลือกผู้บริหารที่ต้องการติดต่อ</strong></span>
    <br><select name="filterpresident" class="form-control" id="filterpresident">
    <option value=" ">ทั้งหมด</option>
    <?PHP 
    $sql1 = "SELECT * FROM President";
    $req = $bdd->prepare($sql1);
    $req->execute();
    $president = $req->fetchAll();
                    
    foreach ($president as $row => $president) 
    {
        if($president['presidentid']==$presidentid){
            $select='selected';
        }else{
            $select="";
        }
        echo  "<option value='".$president['presidentid']."'".$select.">".$president['presidentname']."</option>";
    }
    ?>
    </select><br>
    <?PHP 
    if($presidentid!=" "){
        echo "<span style='font-size:18px;'><strong>ถ้าต้องการจองเวลา กรุณาติดต่อ 08xxxxxxx</strong>";
    }
    ?>
    </span><br>
    <button type="submit" class="btn btn-primary">ค้นหา</button>
    </div>	
    </center>
    </form>

    
    <div class="container">

        <div class="row">
            <div class="col-lg-12 text-center"><br>
                <div id="calendar" class="col-centered">
                </div>
            </div>
			
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- FullCalendar -->
	<script src='js/moment.min.js'></script>
	<script src='js/fullcalendar.min.js'></script>
	
	<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},

			defaultDate: $('#calendar').fullCalendar('today'),
			editable: false,
			eventLimit: true, // allow "more" link when too many events
			selectable: true,
			selectHelper: true,
			select: function(start, end) {
				
				$('#ModalAdd #start').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd #end').val(moment(end).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd').modal('show');
			},
			eventRender: function(event, element) {
				element.bind('dblclick', function() {
					$('#ModalEdit #id').val(event.id);
					$('#ModalEdit #title').val(event.title);
					$('#ModalEdit #color').val(event.color);
					$('#ModalEdit').modal('show');
				});
			},
			eventDrop: function(event, delta, revertFunc) { // si changement de position

				edit(event);

			},
			eventResize: function(event,dayDelta,minuteDelta,revertFunc) { // si changement de longueur

				edit(event);

			},
			events: [
			<?php foreach($events as $event): 
			
				$start = explode(" ", $event['start']);
				$end = explode(" ", $event['end']);
				if($start[1] == '00:00:00'){
					$start = $start[0];
				}else{
					$start = $event['start'];
				}
				if($end[1] == '00:00:00'){
					$end = $end[0];
				}else{
					$end = $event['end'];
				}
			?>
				{
					id: '<?php echo $event['id']; ?>',
					title: '<?php echo $event['title']; ?>',
					start: '<?php echo $start; ?>',
					end: '<?php echo $end; ?>',
					color: '<?php echo $event['color']; ?>',
				},
			<?php endforeach; ?>
			]
		});
		
		function edit(event){
			start = event.start.format('YYYY-MM-DD HH:mm:ss');
			if(event.end){
			end = event.end.format('YYYY-MM-DD HH:mm:ss');
			}else{
				end = start;
			}
			
			id =  event.id;
			
			Event = [];
			Event[0] = id;
			Event[1] = start;
			Event[2] = end;
			
			$.ajax({
			 url: '',
			 type: "POST",
			 data: {Event:Event},
			 success: function(rep) {
					if(rep == 'OK'){
						alert('test Saved');
					}else{
	 					alert('Could not be saved. try again.'); 
				    } 
				} 
			}); 
		}
		
	});

</script>
	<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <form role="form" method="post" action="login.php" >
      <div class="modal-header">
      <h2>เข้าสู่ระบบสมาชิก </h2>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <center>
        <div id='form1' class='col-sm-20 control-label'>
            
        </div>
            <table>
             <tr>
                <td class='t-left'><input class='form-control' id='input-box' type='text' name='username' id='username' placeholder=' ชื่อผู้ใช้งาน / Username' required /></td>
                <td class='t-left'><input class='form-control' id='input-box' type='password' name='password' id='password' placeholder=' รหัสผ่าน / Password' required /></td>
            </tr>
            </table>
        </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ยกเลิก</button>
        <button type="submit" class='btn btn-success' name='login' id='login'>เข้าสู่ระบบ</button>
      </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>
