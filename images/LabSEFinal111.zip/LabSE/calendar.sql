-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2019 at 04:28 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `calendar`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `depart` varchar(50) NOT NULL,
  `tel` varchar(12) NOT NULL,
  `detail` varchar(300) NOT NULL,
  `title` varchar(255) NOT NULL,
  `local` varchar(50) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `presidentid` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `fullname`, `depart`, `tel`, `detail`, `title`, `local`, `color`, `start`, `end`, `presidentid`) VALUES
(19, 'นางสาวจุฑามาส  จินจิว', 'เทศบาล', '0619408146', 'ประทานเปิดงานโอท็อปจังหวัดขอนแก่น', 'โอท็อปเมืองขอนแก่น', 'โรงแรม', '#88e85c', '2019-05-03 08:30:00', '2019-05-03 09:30:00', 1),
(22, 'จิรพงษ์ เรียนพิษ', '', '940139961', '', 'พรีเซนต์โปรเจค', '', '#88e85c', '2019-05-02 03:00:00', '2019-05-02 08:00:00', 1),
(24, 'จิรพงษ์ เรียนพิษ', '', '940139961', '', 'เปิดโรงงาน', '', '#88e85c', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(25, 'จิรพงษ์ เรียนพิษ', 'เทศบาล', '0940139961', 'DSFSGDGHDHSD', 'โอท็อปเมืองขอนแก่น', '', '#ffbd91', '2019-05-16 07:00:00', '2019-05-16 08:00:00', 3),
(26, 'jirapong rianphit', 'เทศบาล', '0940139961', 'ghgfhdf', 'พรีเซนต์โปรเจค', 'ขอนแก่น', '#ffbd91', '2019-05-10 07:00:00', '2019-05-10 08:00:00', 2),
(27, 'จิรพงษ์ เรียนพิษ', 'เทศบาล', '0940139961', '', 'โอท็อปเมืองขอนแก่น', 'สีชมพู', '#ffbd91', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `president`
--

CREATE TABLE `president` (
  `presidentid` int(4) NOT NULL,
  `presidentname` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `president`
--

INSERT INTO `president` (`presidentid`, `presidentname`, `position`) VALUES
(1, 'นายธีระศักดิ์ ฑีฆายุพันธุ์', 'นายกเทศมนตรี'),
(2, 'ดร.กฤษณวรุณ  ไชยนิจ', 'ปลัดเทศบาล'),
(3, 'นางกฤษณา  แสนสอาด', 'รองปลัดเทศบาล'),
(4, 'นายสุปัทม์  ทองรัตน์', 'รองปลัดเทศบาล'),
(5, 'นายธนาวุธ  ก้อนใจจิตร', 'รองปลัดเทศบาล');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(3) NOT NULL,
  `name_surname` varchar(50) NOT NULL,
  `username` varchar(13) NOT NULL,
  `password` varchar(8) NOT NULL,
  `department` varchar(60) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `type` varchar(2) NOT NULL,
  `presidentid` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name_surname`, `username`, `password`, `department`, `tel`, `type`, `presidentid`) VALUES
(0, 'as sd', 'admin', '1234', 'it', '185602', '01', 1),
(3, 'asdadasasd', 'aaaa', 'aaaa', 'cs', '564861503', '02', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `president`
--
ALTER TABLE `president`
  ADD PRIMARY KEY (`presidentid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
