<?php 
session_start();
if (!isset($_SESSION['usr']))
  {	
     echo "<script>alert('กรุณาเข้าสู่ระบบก่อน')</script>"; 
     echo "<script type='text/javascript'>window.location.href = 'logout.php';</script>"; 
  }
?>