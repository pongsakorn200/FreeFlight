-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2019 at 10:08 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ff`
--

-- --------------------------------------------------------

--
-- Table structure for table `airline`
--

CREATE TABLE `airline` (
  `AirlineID` varchar(6) NOT NULL,
  `AirlineName` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `airline`
--

INSERT INTO `airline` (`AirlineID`, `AirlineName`) VALUES
('TH-01', 'สายการบินการบินไทย'),
('TH-02', 'สายการบินนกแอร์'),
('TH-03', 'สายการบินแอร์เอเชีย');

-- --------------------------------------------------------

--
-- Table structure for table `airport`
--

CREATE TABLE `airport` (
  `AirPortID` varchar(4) NOT NULL,
  `AirPortName` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `airport`
--

INSERT INTO `airport` (`AirPortID`, `AirPortName`) VALUES
('TH01', 'สนามบินสุวรรภูมิ'),
('TH02', 'สนามบินดอนเมือง');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerID` int(5) NOT NULL,
  `payMentID` varchar(4) DEFAULT NULL,
  `title` varchar(10) NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `tel` varchar(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `PersonalID` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerID`, `payMentID`, `title`, `Fname`, `Lname`, `tel`, `email`, `username`, `password`, `PersonalID`) VALUES
(1, NULL, 'นาย', 'สุระชาติ', 'มะณีพันธ์', '0990291770', 'masker4de@gmail.com', 'masker4de', 'masker4de', '1459900000000'),
(2, NULL, 'นางสาว', 'สุดสวย', 'และรวยมาก', '0822347171', 'sudsuay@kkumail.com', 'sudsuay', 'sudsuay', '1300000000000'),
(4, NULL, 'นาย', 'สุระชาติ', 'มะณีพันธ์', '0990291770', 'flukeseyhey@gmail.com', 'admin', 'admin', '1234567890123'),
(5, NULL, 'นางสาว', 'สุระชาติ', 'มะณีพันธ์', '0990291770', 'flukeseyhey@gmail.com', 'maskerade', 'sef', '1234567890123');

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `flightID` int(8) NOT NULL,
  `AirPortID` varchar(4) NOT NULL,
  `flightTime` date DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `AirlineID` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`flightID`, `AirPortID`, `flightTime`, `Price`, `AirlineID`) VALUES
(3, 'TH01', '2019-05-15', 25000, 'TH-01'),
(4, 'TH01', '2019-05-27', 26900, 'TH-02'),
(5, 'TH02', '2019-04-23', 26900, 'TH-03'),
(6, 'TH02', '2019-05-13', 26900, 'TH-01');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `customerID` int(5) NOT NULL,
  `payMentID` varchar(4) NOT NULL,
  `PersonalID` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `order_info`
--

CREATE TABLE `order_info` (
  `orderID` int(7) NOT NULL,
  `flightID` int(8) NOT NULL,
  `seat_number` varchar(4) DEFAULT NULL,
  `passengerName` varchar(45) DEFAULT NULL,
  `baggage` int(3) DEFAULT NULL,
  `flight_AirPortID` varchar(4) NOT NULL,
  `customerID` int(5) NOT NULL,
  `payMentID` varchar(4) NOT NULL,
  `PersonalID` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `paymentmethod`
--

CREATE TABLE `paymentmethod` (
  `payMentID` varchar(4) NOT NULL,
  `payMentName` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `promotion`
--

CREATE TABLE `promotion` (
  `promotionID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `promotionName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `promotion`
--

INSERT INTO `promotion` (`promotionID`, `promotionName`, `price`) VALUES
('0001', 'Wonder visit campaign', 50),
('2', 'ONE WAY TO AUSTRALIA AND NEW ZEALAND', 69),
('3', 'AUSTRALASIA DELIGHT FOR 2', 30),
('4', 'เที่ยวหน้าร้อนก่อนเปิดเทอม', 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airline`
--
ALTER TABLE `airline`
  ADD PRIMARY KEY (`AirlineID`);

--
-- Indexes for table `airport`
--
ALTER TABLE `airport`
  ADD PRIMARY KEY (`AirPortID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`),
  ADD KEY `fk_paymentmethod_customer` (`payMentID`) USING BTREE;

--
-- Indexes for table `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`flightID`),
  ADD KEY `fk_flight_Airline` (`AirlineID`),
  ADD KEY `fk_flight_AirPort` (`AirPortID`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`customerID`,`payMentID`,`PersonalID`),
  ADD KEY `fk_customer_order_customerid` (`customerID`) USING BTREE,
  ADD KEY `fk_customer_order_personalid` (`PersonalID`) USING BTREE,
  ADD KEY `fk_paymenthod_order_paymentid` (`payMentID`) USING BTREE;

--
-- Indexes for table `order_info`
--
ALTER TABLE `order_info`
  ADD PRIMARY KEY (`orderID`) USING BTREE,
  ADD KEY `fk_flight_order_info` (`flightID`);

--
-- Indexes for table `paymentmethod`
--
ALTER TABLE `paymentmethod`
  ADD PRIMARY KEY (`payMentID`);

--
-- Indexes for table `promotion`
--
ALTER TABLE `promotion`
  ADD PRIMARY KEY (`promotionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `flight`
--
ALTER TABLE `flight`
  MODIFY `flightID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_info`
--
ALTER TABLE `order_info`
  MODIFY `orderID` int(7) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `fk_paymentmethod_customer` FOREIGN KEY (`payMentID`) REFERENCES `paymentmethod` (`payMentID`);

--
-- Constraints for table `flight`
--
ALTER TABLE `flight`
  ADD CONSTRAINT `fk_flight_AirPort` FOREIGN KEY (`AirPortID`) REFERENCES `airport` (`AirPortID`),
  ADD CONSTRAINT `fk_flight_Airline` FOREIGN KEY (`AirlineID`) REFERENCES `airline` (`AirlineID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
