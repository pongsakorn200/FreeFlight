<?php  
include("conn.php");  
  
if(isset($_POST['login']))  
{  
    $username=$_POST['username'];  
    $password=$_POST['password'];  
  
    $check_user="select * from user WHERE username='$username' AND password='$password'";  
  
    $result = $conn->query($check_user);
    
	$row=mysqli_fetch_array($result);
	session_write_close();
    session_start();
 if ($result->num_rows > 0)	 
    {
        if ($row['type']=="01")
		{	
            
            $_SESSION['usr'] = $row['username'];
		    $_SESSION['presidentid'] = $row['presidentid'];
            echo "<script>window.open('main_admin.php','_self')</script>";
        }	
        if ($row['type']=="02")
		{	
            
            $_SESSION['usr'] = $row['username'];
		    $_SESSION['presidentid'] = $row['presidentid'];
           echo "<script>window.open('main_staff.php','_self')</script>";
		}		
    }  
    else  
    {  
       echo "<script>alert('username or password is incorrect!')</script>";  
	   echo "<script>window.open('logout.php','_self')</script>";  
    }  
}

?>